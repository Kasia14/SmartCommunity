import React, { useEffect, useState } from "react";
import { fetchUsers } from "./api";
import UserCards from "./UserCards";
import { useInterval } from "./interval";
const App = () => {
  const [users, setUsers] = useState(null);

  useEffect(async () => {
    const users = await fetchUsers();
    setUsers(users);
    console.log(users);
  }, []);

  useInterval(async () => {
    const users = await fetchUsers();
    setUsers(users);
  }, 30 * 1000);
  if (!users) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <UserCards users={users} />
    </div>
  );
};

export default App;
