"use strict";

const express = require("express");
const generateUser = require('./generateUserStorage');

module.exports.create = function initServer() {
  const server = express();

  server.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header(
      "Access-Control-Allow-Headers",
      "Origin, X-Requested-With, Content-Type, Accept"
    );
    next();
  });

  server.get("/storage", function (req, res) {
    const users = new Array(50).fill(0).map((_, i) => generateUser(i + 1));

    res.json(users);
  });

  server.get(/.*/, express.static("app"));

  return server;
};
