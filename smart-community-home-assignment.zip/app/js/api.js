export const fetchUsers = async () => {
  const resp =  await fetch('http://localhost:9000/storage').then(data => data.json())
  return resp;
  // console.log(resp)
} 