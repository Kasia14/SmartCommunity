import React, { useState } from 'react';

const UserCard = ({ id, avatar, firstName, lastName, photoCount, folderByteSize}) => {

  return (
   <section className="cards">
    <article className="card">
    <img className="card--image" src={avatar} alt="avatar"/>
    <h2 className="card--title">{firstName} {lastName}</h2>
    <small className="card--size">{(folderByteSize/1024/1024).toFixed(2)}MB ({photoCount} photos)</small>
  </article>
  </section>
  );
};

export default UserCard;