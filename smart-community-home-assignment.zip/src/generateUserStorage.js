"use strict";

const faker = require("faker");
module.exports = function generateUserStorage(id) {

  faker.seed(id);
  const firstName = faker.name.firstName();
  const lastName = faker.name.lastName();
  const gender = ['women', 'men'][faker.random.number({ min: 0, max: 1})]
  const avatar = `https://randomuser.me/api/portraits/${gender}/${id}.jpg`;
  const photoCount = faker.random.number({ min: 8, max: 64 });
  const folderByteSize = photoCount * 5 * 1024 * (faker.random.number({ min: 0.3, max: 0.5 }) + 0.8);

  return {
    id,
    firstName,
    lastName,
    avatar,
    photoCount,
    folderByteSize
  };
};
